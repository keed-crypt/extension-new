document.addEventListener('DOMContentLoaded', () => {
  // Helper function to format large numbers
  const formatLargeNumber = (num) => {
    if (num >= 1e9) {
      return (num / 1e9).toFixed(1) + 'B';
    } else if (num >= 1e6) {
      return (num / 1e6).toFixed(1) + 'M';
    }
    return num.toFixed(1);
  };

  let chartInstance = null; // Global variable to store chart instance

  document.getElementById('getInfo').addEventListener('click', async () => {
    const contractAddress = document.getElementById('contractAddress').value;

    if (!contractAddress) {
      document.getElementById('output').textContent = "Please enter a contract address.";
      return;
    }

    try {
      // Fetch token info from your backend
      const response = await fetch('https://rug-check-backend-cd671e950746.herokuapp.com/api/getFullTokenDetails', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contractAddress, tokenMint: contractAddress })
      });

      const data = await response.json();

      if (response.ok) {
        document.getElementById('output').innerHTML = '';

        const tokenIconUrl = data.chart_data.pairs[0].info.imageUrl || '';
        if (tokenIconUrl) {
          const logo = document.createElement('img');
          logo.src = tokenIconUrl;
          logo.alt = `${data.name} icon`;
          logo.style.width = '120px';
          logo.style.display = 'block';
          logo.style.margin = '0 auto';
          document.getElementById('output').appendChild(logo);
        }

        const createInfoBox = (label, value) => `
          <div class="info-box">
            <div class="info-label">${label}:</div>
            <div class="info-value">${value}</div>
          </div>
        `;

        document.getElementById('output').innerHTML += createInfoBox('Name', data.name);
        document.getElementById('output').innerHTML += createInfoBox('Symbol', data.symbol);
        document.getElementById('output').innerHTML += createInfoBox('Description', data.description || 'No description available');
        document.getElementById('output').innerHTML += createInfoBox('Price per Token', data.price_per_token || 'Price info not available');
        document.getElementById('output').innerHTML += createInfoBox('Total Supply', formatLargeNumber(parseFloat(data.total_supply)));
        document.getElementById('output').innerHTML += createInfoBox('Burn Percentage', data.burn_percentage || 'No burn info');
        document.getElementById('output').innerHTML += createInfoBox('Mint Authority', data.mint_authority === 'Disabled' ? 'Disabled' : 'Enabled');
        document.getElementById('output').innerHTML += createInfoBox('Freeze Authority', data.freeze_authority === 'Disabled' ? 'Disabled' : 'Enabled');

        // Render Chart.js bar chart
        renderBarChart(data);

        // Fetch token transfers for Dot2Dot visualization
        const transferResponse = await fetch(`https://rug-check-backend-cd671e950746.herokuapp.com/api/getTokenTransfers?contractAddress=${contractAddress}`);
        const transferData = await transferResponse.json();

        // Render Dot2Dot graph
        renderDot2DotGraph(transferData.nodes, transferData.links);

      } else {
        document.getElementById('output').textContent = 'Error fetching token info.';
      }
    } catch (error) {
      document.getElementById('output').textContent = 'Error: ' + error.message;
      console.error('Error fetching token info:', error);
    }
  });

  // Chart.js rendering function with proper chart destruction
  function renderBarChart(data) {
    const canvas = document.getElementById('dexChartCanvas');
    const ctx = canvas.getContext('2d');

    // If a chart instance exists, destroy it
    if (chartInstance) {
      chartInstance.destroy();  // Destroy the existing chart instance
    }

    // Clear the canvas to avoid issues with overlapping charts
    ctx.clearRect(0, 0, canvas.width, canvas.height);  // Clear the canvas manually

    const txnsData = data.chart_data.pairs[0].txns;

    const buyCounts = [];
    const sellCounts = [];
    const timeIntervals = [];

    if (txnsData.h24) {
      buyCounts.push(txnsData.h24.buys);
      sellCounts.push(txnsData.h24.sells);
      timeIntervals.push('24h');
    }
    if (txnsData.h6) {
      buyCounts.push(txnsData.h6.buys);
      sellCounts.push(txnsData.h6.sells);
      timeIntervals.push('6h');
    }
    if (txnsData.h1) {
      buyCounts.push(txnsData.h1.buys);
      sellCounts.push(txnsData.h1.sells);
      timeIntervals.push('1h');
    }

    // Create a new chart instance
    chartInstance = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: timeIntervals,
        datasets: [
          {
            label: 'Buys',
            data: buyCounts,
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 2
          },
          {
            label: 'Sells',
            data: sellCounts,
            backgroundColor: 'rgba(255, 99, 132, 0.2)',
            borderColor: 'rgba(255, 99, 132, 1)',
            borderWidth: 2
          }
        ]
      },
      options: {
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
  }

  // D3.js Dot2Dot rendering function
  function renderDot2DotGraph(nodes, links) {
    d3.select('#dot2dot-graph').selectAll('*').remove();

    const width = 350;
    const height = 300;

    const svg = d3
      .select('#dot2dot-graph')
      .append('svg')
      .attr('width', width)
      .attr('height', height);

    const simulation = d3
      .forceSimulation(nodes)
      .force('link', d3.forceLink(links).id(d => d.id).distance(100))
      .force('charge', d3.forceManyBody().strength(-200))
      .force('center', d3.forceCenter(width / 2, height / 2));

    const link = svg
      .append('g')
      .attr('stroke', '#999')
      .attr('stroke-opacity', 0.6)
      .selectAll('line')
      .data(links)
      .enter()
      .append('line')
      .attr('stroke-width', d => Math.sqrt(d.value));

    const node = svg
      .append('g')
      .attr('stroke', '#fff')
      .attr('stroke-width', 1.5)
      .selectAll('circle')
      .data(nodes)
      .enter()
      .append('circle')
      .attr('r', 5)
      .attr('fill', 'steelblue')
      .call(d3.drag()
        .on('start', dragstarted)
        .on('drag', dragged)
        .on('end', dragended));

    node.append('title').text(d => d.id);

    simulation.on('tick', () => {
      link
        .attr('x1', d => d.source.x)
        .attr('y1', d => d.source.y)
        .attr('x2', d => d.target.x)
        .attr('y2', d => d.target.y);

      node
        .attr('cx', d => d.x)
        .attr('cy', d => d.y);
    });

    function dragstarted(event, d) {
      if (!event.active) simulation.alphaTarget(0.3).restart();
      d.fx = d.x;
      d.fy = d.y;
    }

    function dragged(event, d) {
      d.fx = event.x;
      d.fy = event.y;
    }

    function dragended(event, d) {
      if (!event.active) simulation.alphaTarget(0);
      d.fx = null;
      d.fy = null;
    }
  }
});
